from __future__ import print_function
import tweepy
#import pandas as pd
import pickle


sourceFile = open('/home/hduser/Husain/hockey.txt', 'w')


####input your credentials here
consumer_key = 'j8VgFM8EPGT44SmhMHLhfygAg'
consumer_secret = 'LA2f5RV3ZpGBomNieHTsbkrwHoI1vCFF6nDcfY3tflDmwR8bzf'
access_token = '1021333083490930688-kfnhYlpImNXuerYwWxba1ozx5cG7LE'
access_token_secret = 'kf4UU46Rxd4iyOLu293KZzdTUKHdwa8hWHp5WhPk09p1i'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth,wait_on_rate_limit=True)

for tweet in tweepy.Cursor(api.search,q=["Hockey"],
                           lang="en",
                           since="2017-04-03").items(20):
    #pickle.dump([tweet.created_at, tweet.text.encode('utf-8')], sourceFile)
    print (tweet.created_at, tweet.text.encode('utf-8'), file = sourceFile, sep = "*")
    
sourceFile.close()