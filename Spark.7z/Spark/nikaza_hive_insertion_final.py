#================================ import the necassary modules for script =====================================

from pyspark import SparkContext, SparkConf, SQLContext
from pyspark.sql.functions import col, explode, size, udf, monotonically_increasing_id, split, unix_timestamp, isnan, when, count
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from shapely.geometry.polygon import Polygon
from shapely.geometry import shape, Point, Polygon
from pyspark import SparkContext
from pyspark.sql import HiveContext
import json
import codecs
import sys

#========================== Script configurations ============================

INPUT_FILE = str(sys.argv[1])
OUTPUT_FILE = str(sys.argv[2])
jdata = open(str(sys.argv[3]),'r').read()

#======================== start the driver, hive context and sql context =======================================

conf = SparkConf().setMaster("yarn").setAppName("nikaza")
sc = SparkContext(conf = conf)
spark = SparkSession.builder.appName('nikaza').getOrCreate()
sqlContext = SQLContext(sc)
hcon = HiveContext(sc)

#========================== reading the users data and polygon data ============================================

lines = sc.textFile(INPUT_FILE)
header = 'app_id,user_idfa,user_idfa_limited,device_os_type,device_location_lat,device_location_lng,device_location_accuracy,event_localtime,event_time_utc,event_type,app_state,application_id,IP address'
lines = lines.filter(lambda row: row != header)
lines.cache()

pp = json.loads(jdata)
feature_collection = pp['features']

#================================== broadcast the geojson data throughout =======================================
	
BROAD_GEOJSON_FILE = sc.broadcast(feature_collection)


#================================ filter the users that are present in atleast one polygon ======================

for x in range(len(BROAD_GEOJSON_FILE.value)):
	poly = Polygon(BROAD_GEOJSON_FILE.value[x]['geometry']['coordinates'][0])
	feature_points1 = lines.filter(lambda j: poly.contains(Point(float(j.split(',')[5]), float(j.split(',')[4])))).map(lambda j: j+","+str(x+1)).saveAsTextFile(OUTPUT_FILE+str(x+1))