import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.*;
public class TestHBase {
       public static void main(String[] args) throws Exception {
            Configuration conf = HBaseConfiguration.create();
            HBaseAdmin admin = new HBaseAdmin(conf);
            try {
		
                HTable table1 = new HTable(conf, "test-table");
                Put put = new Put(Bytes.toBytes("test-key"));
                put.add(Bytes.toBytes("details"), Bytes.toBytes("name"), Bytes.toBytes("Husain"));
                table1.put(put);
            } finally {
                admin.close();
            }
        }
}