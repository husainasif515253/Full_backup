#from pyhive import hive
#conn = hive.Connection(host="192.168.5.89", port=22, username="hduser")

#cursor = conn.cursor()
#cursor.execute("SELECT * FROM india")

#for result in cursor.fetchall():
#	use_result(result)
	
import pyhs2

with pyhs2.connect(host='192.168.5.89',
               port=22,
               user='hduser',
               password='avl@1234',
               database='twitter') as conn:
    with conn.cursor() as cur:
        #Show databases
        print cur.getDatabases()

        #Execute query
        cur.execute("SELECT time FROM india")

        #Return column info from query
        print cur.getSchema()

        #Fetch table results
        for i in cur.fetch():
            print i