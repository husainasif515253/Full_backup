import time
import json
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.sql import SQLContext
from pyspark.sql.types import StructType, ArrayType

def filter_tweets(tweet):
    json_tweet = json.loads(tweet)
    if json_tweet.has_key('lang'): # When the lang key was not present it caused issues
        if json_tweet['lang'] == 'en':
            return True # filter() requires a Boolean value
    return False

def flatten(schema, prefix = None):
	fields = []
	for field in schema.fields:
		name = prefix + '.' + field.name if prefix else field.name
		dtype = field.dataType
		if isinstance(dtype, ArrayType):
			dtype = dtype.elementType
		if isinstance(dtype, StructType):
			fields += flatten(dtype, prefix=name)
		else:
			fields.append(name)
	return(fields)

sc = SparkContext("local", "twitter demo")
sqlcontext = SQLContext(sc)
ssc = StreamingContext(sc, 10) #10 is the batch interval in seconds
IP = "localhost"
Port = 9098
lines = ssc.socketTextStream(IP, Port)
#lines.pprint()
lines.saveAsTextFiles("file:///home/ubuntu1/husain/flask_streaming/tweets_revised/")
#lines.foreachRDD(lambda x : sqlContext.read.json(x).coalesce(1).write.format('parquet').option("delimiter", "|").save("file:///home/ubuntu1/husain/flask_streaming/tweets_revised2/%f" % time.time()))
lines.foreachRDD(lambda x : x.saveAsTextFile("file:///home/ubuntu1/husain/flask_streaming/tweets_revised2/%f" % time.time()))

#lines.foreachRDD(lambda x: sqlContext.read.json(x).select(flatten(sqlContext.read.json(x).schema)).write.format('text').option("delimiter", ";").save("file:///home/ubuntu1/husain/flask_streaming/tweets_revised2/%f" % time.time()))

ssc.start()
#ssc.awaitTermination()



