from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import explode
from pyspark.sql.functions import split
from pyspark.sql import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
from shapely.geometry.polygon import Polygon
from shapely.geometry import shape, Point, Polygon
import json

conf = SparkConf().setMaster('yarn').setAppName('nikaza')
sc = SparkContext(conf = conf)
sqlContext = SQLContext(sc)
spark = SparkSession.builder.appName('nikaza').getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", 4)

schema_data=StructType([StructField('app_id',StringType(),True),StructField('user_idfa',StringType(),True),StructField('user_idfa_limited',StringType(),True),StructField('device_os_type',StringType(),True),StructField('device_location_lat',DoubleType(),True),StructField('device_location_lng',DoubleType(),True),StructField('device_location_accuracy',StringType(),True),StructField('event_localtime',StringType(),True),StructField('event_time_utc',StringType(),True),StructField('event_type',StringType(),True),StructField('app_state',StringType(),True),StructField('application_id',StringType(),True),StructField('ip_address',StringType(),True)])

#schema_data2=StructType([StructField('app_id',StringType(),True),StructField('user_idfa',StringType(),True),StructField('user_idfa_limited',StringType(),True),StructField('device_os_type',StringType(),True),StructField('device_location_lat',DoubleType(),True),StructField('device_location_lng',DoubleType(),True),StructField('device_location_accuracy',StringType(),True),StructField('event_localtime',StringType(),True),StructField('event_time_utc',StringType(),True),StructField('event_type',StringType(),True),StructField('app_state',StringType(),True),StructField('application_id',StringType(),True),StructField('ip_address',StringType(),True), StructField('polygon_id',StringType(),True),StructField('status',StringType(),True)])

#final_dataframe = spark.createDataFrame(sc.emptyRDD(), schema_data2)

user_data = spark.readStream.schema(schema_data).option('maxFilesPerTrigger',1).csv('hdfs:/user/ubuntu1/husain/nikaza/test_data/')

jdata = open('/home/ubuntu1/husain/nikaza/polygon_data/geojson_data.json','r').read()
pp = json.loads(jdata)
feature_collection = pp['features']
BROAD_GEOJSON_FILE = sc.broadcast(feature_collection)
polygon_objects = []
for x in range(len(BROAD_GEOJSON_FILE.value)):
	polygon_objects.append(Polygon(BROAD_GEOJSON_FILE.value[x]['geometry']['coordinates'][0]))

def pop(poly,longitude, latitude):
	return(polygon_objects[poly].contains(Point(float(longitude), float(latitude))))

point_in_poly = udf(pop)

for i in range(len(polygon_objects)):
	x = user_data.withColumn("polygon_id", lit(i))
	x = x.withColumn('status', point_in_poly(lit(i),x['device_location_lng'], x['device_location_lat']))
	x = x.select('*').where('status == true')		
	x.writeStream.queryName(str('example'+str(i))).format('console').outputMode('append').start()






