package kafka1.kafka11;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.zip.GZIPInputStream;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

public class SimpleProducer {
   public static void main(String[] args) throws Exception{
	  String topicName = "test2";
	  Properties props = new Properties();
	  props.put("bootstrap.servers", "localhost:9092");
	  props.put("acks", "all");
	  props.put("retries", 0);
	  props.put("batch.size", 16384);
	  props.put("linger.ms", 1);
	  props.put("buffer.memory", 33554432);
      props.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
	  props.put("value.serializer","org.apache.kafka.common.serialization.StringSerializer");
	  Producer<String, String> producer = new KafkaProducer<String, String>(props);
	  Path usFolder = Paths.get("E:\\nikaza\\us_test");
	  WatchService watchService = FileSystems.getDefault().newWatchService();
	  usFolder.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
	  boolean valid = true;
	  do {
		  WatchKey watchKey = watchService.take();
		  for (WatchEvent event : watchKey.pollEvents()) {
				WatchEvent.Kind kind = event.kind();
				if (StandardWatchEventKinds.ENTRY_CREATE.equals(event.kind())) {
					String fileName = event.context().toString();
					String context = "E:\\nikaza\\us_test\\"+fileName;
					GZIPInputStream gzip = new GZIPInputStream(new FileInputStream(context));
					BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
					String content;
					while ((content = br.readLine()) != null) {
				    	  producer.send(new ProducerRecord<String, String>(topicName, Integer.toString(10), content));
				    }
				}
		  }
		  valid = watchKey.reset();
	  }while(valid);
	  
	  //File path = new File("E:\\nikaza\\us");
	  //File [] files = path.listFiles();
	  //for(int i=0; i<files.length; i++) {
		  //GZIPInputStream gzip = new GZIPInputStream(new FileInputStream(files[i]));
		  //BufferedReader br = new BufferedReader(new InputStreamReader(gzip));
		  //String content;
		  //while ((content = br.readLine()) != null) {
	    	  //producer.send(new ProducerRecord<String, String>(topicName, Integer.toString(10), content));
	      //}
	  //}
      System.out.println("Message sent successfully");
      //producer.close();         
   }
}