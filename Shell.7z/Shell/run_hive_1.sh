FILES=/home/hduser/nikaza/files.properties
hive_script_path_1=$(grep -i 'hive_script_path_1' $FILES  | cut -f2 -d'=')
db_name=$(grep -i 'db_name' $FILES  | cut -f2 -d'=')
table_name=$(grep -i 'table_name' $FILES  | cut -f2 -d'=')
table=$db_name"."$table_name
OUTPUT_FILE=$(grep -i 'OUTPUT_FILE' $FILES  | cut -f2 -d'=')

hive --hiveconf db_name=$db_name --hiveconf table=$table --hiveconf OUTPUT_FILE=$OUTPUT_FILE -f $hive_script_path_1 