FILES=/home/hduser/nikaza/files.properties
hive_script_path_2=$(grep -i 'hive_script_path_2' $FILES  | cut -f2 -d'=')
db_name=$(grep -i 'db_name' $FILES  | cut -f2 -d'=')
location_user_data_table=$(grep -i 'location_user_data_table' $FILES  | cut -f2 -d'=')
table_name=$(grep -i 'table_name' $FILES  | cut -f2 -d'=')

hive --hiveconf db_name=$db_name --hiveconf location_user_data_table=$location_user_data_table --hiveconf table_name=$table_name -f $hive_script_path_2