hdp_input_loc="hadoop fs -ls /user/cloudera/husain/nikaza_input/"
hdp_output_loc="/user/cloudera/husain/nikaza_output/"
for filename in `$hdp_input_loc | awk '{print $NF}'`
do 
    input_loc=$filename;
    part=${filename##*/}
    hive --hiveconf location_input=$input_loc --hiveconf partition=$part --hiveconf location_output=$hdp_output_loc -f hive_cmds.hql	
done