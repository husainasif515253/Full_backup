FILES=/home/hduser/nikaza/files.properties
nikaza_hive_insertion_final_path=$(grep -i 'nikaza_hive_insertion_final_path' $FILES  | cut -f2 -d'=')

INPUT_FILE=$(grep -i 'INPUT_FILE' $FILES  | cut -f2 -d'=')
OUTPUT_FILE=$(grep -i 'OUTPUT_FILE' $FILES  | cut -f2 -d'=') 
jdata=$(grep -i 'jdata' $FILES  | cut -f2 -d'=')
db_name=$(grep -i 'db_name' $FILES  | cut -f2 -d'=')
table_name=$(grep -i 'table_name' $FILES  | cut -f2 -d'=')
spark_submit_path=$(grep -i 'spark_submit_path' $FILES  | cut -f2 -d'=')

$spark_submit_path"spark-submit" --master yarn --num-executors 6 --executor-cores 2 --executor-memory 1g --driver-memory 2g $nikaza_hive_insertion_final_path "$INPUT_FILE" "$OUTPUT_FILE" "$jdata"